class person {
    String name;
    int age;
}
