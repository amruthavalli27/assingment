public class singleton {
    private static singleton instance;
}
