public class logical {
    public static void main(String[] args) {
        int a=2,b=4;
        if(a==2&&b==3){
            System.out.println("Hello");
        }
        else{
            System.out.println("bye");
        }
    }
}
