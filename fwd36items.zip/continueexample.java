public class continueexample {
    public static void main(String[] args) {
        System.out.println("example of using continue");
        for (int i=1;i<=3;i++){
            System.out.println("outer loop:" +i);
        }
    }
}
