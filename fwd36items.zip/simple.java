public class simple{
    public static void main(String[] args) {
        int a=10,b=3;
        if(a==b){
            System.out.println("a is equal to b");
        }
        else{
            if(a>b){
                System.out.println("a is grater than b");
            }
            else{
                System.out.println("a is less than b");
            }
        }
    }
}
